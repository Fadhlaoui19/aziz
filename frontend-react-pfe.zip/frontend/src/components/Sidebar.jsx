import { Link, useLocation } from "react-router-dom";

export default function Sidebar({ setToken }) {
  const location = useLocation();
  const linkStyle = (path) => `block px-4 py-2 ${location.pathname === path ? "bg-blue-100" : "hover:bg-gray-100"}`;

  return (
    <aside className="w-64 bg-white h-screen shadow-md">
      <nav className="p-4">
        <h1 className="text-xl font-bold mb-4">Tableau de bord</h1>
        <Link to="/" className={linkStyle("/")}>Accueil</Link>
        <Link to="/vehicles" className={linkStyle("/vehicles")}>Véhicules</Link>
        <Link to="/missions" className={linkStyle("/missions")}>Missions</Link>
        <Link to="/fuel" className={linkStyle("/fuel")}>Carburant</Link>
        <button onClick={() => setToken(null)} className="mt-4 text-red-600">Déconnexion</button>
      </nav>
    </aside>
  );
}
