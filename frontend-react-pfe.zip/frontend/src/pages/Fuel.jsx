export default function Fuel() {
  return <h2 className="text-xl font-semibold">Suivi du carburant</h2>;
}
