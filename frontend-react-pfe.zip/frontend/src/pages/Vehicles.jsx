export default function Vehicles() {
  return <h2 className="text-xl font-semibold">Gestion des véhicules</h2>;
}
