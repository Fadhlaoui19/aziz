export default function Dashboard() {
  return <h2 className="text-2xl font-semibold">Bienvenue dans le tableau de bord</h2>;
}
