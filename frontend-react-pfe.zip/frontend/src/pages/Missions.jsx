export default function Missions() {
  return <h2 className="text-xl font-semibold">Gestion des missions</h2>;
}
